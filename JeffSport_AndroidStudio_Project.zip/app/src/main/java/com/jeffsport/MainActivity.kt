package com.jeffsport

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private lateinit var statusLine: TextView
    private var refreshJob: Job? = null
    private var selectedTab = "HOME"
    private var cachedMatches: List<Match> = emptyList()
    private var cachedNews: List<News> = emptyList()
    private var cachedStandings: List<Standing> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 32)
        window.navigationBarColor = Color.rgb(16, 24, 32)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,247,250)) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 16); setBackgroundColor(Color.rgb(16,24,32))
        }
        header.addView(label("JEFF SPORT", 27f, Color.WHITE, true))
        header.addView(label("LIVE SCORES  •  NEWS  •  FOOTBALL", 12f, Color.rgb(244,196,48), true))
        page.addView(header)
        statusLine = label("Inaunganisha...", 12f, Color.DKGRAY, false).apply { setPadding(16,10,16,4) }
        page.addView(statusLine)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14,6,14,18) }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this).apply { setPadding(4,8,4,8); setBackgroundColor(Color.rgb(16,24,32)) }
        listOf("HOME","LIVE","SCORES","NEWS","TABLE").forEach { tab ->
            val b = Button(this).apply {
                text = tab; textSize = 10f; isAllCaps = false
                setTextColor(if(tab==selectedTab) Color.rgb(244,196,48) else Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { selectedTab=tab; render() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        page.addView(nav)
        setContentView(page)
        render()
        refreshJob = lifecycleScope.launch {
            while (isActive) {
                refreshData()
                delay(15000)
            }
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(title: String, detail: String, live: Boolean = false, match: Match? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16,14,16,14)
            setBackgroundColor(Color.WHITE); elevation = 2f
        }
        box.addView(label(title, 16f, Color.rgb(20,30,40), true))
        box.addView(label(detail, 13f, if(live) Color.rgb(190,35,45) else Color.DKGRAY, false).apply { setPadding(0,7,0,0) })
        if (match?.stream_url?.isNotBlank() == true) {
            val watch = Button(this).apply {
                text = "▶ TAZAMA LIVE"; setOnClickListener {
                    startActivity(Intent(this@MainActivity, WatchLiveActivity::class.java).putExtra("streamUrl", match.stream_url))
                }
            }
            box.addView(watch)
        }
        val lp = LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12
        content.addView(box, lp)
    }

    private fun render() {
        content.removeAllViews()
        when(selectedTab) {
            "HOME" -> {
                content.addView(label("Karibu JEFF SPORT", 22f, Color.rgb(16,24,32), true))
                content.addView(label("Matokeo, habari na mechi zinazoendelea.", 14f, Color.DKGRAY, false).apply { setPadding(0,4,0,14) })
                val live = cachedMatches.filter { it.status.equals("LIVE",true) }
                content.addView(label("MECHI LIVE", 18f, Color.rgb(190,35,45), true))
                if(live.isEmpty()) card("Hakuna mechi LIVE", "Mechi za moja kwa moja zitaonekana hapa.")
                live.forEach { card("${it.home_team}  ${it.home_score} - ${it.away_score}  ${it.away_team}", "${it.minute.orEmpty()}  •  ${it.league.orEmpty()}", true, it) }
                content.addView(label("HABARI ZA MICHEZO", 18f, Color.rgb(16,24,32), true).apply { setPadding(0,8,0,8) })
                cachedNews.take(5).forEach { card(it.headline, it.body) }
            }
            "LIVE" -> {
                content.addView(label("MECHI LIVE", 20f, Color.rgb(190,35,45), true))
                val items=cachedMatches.filter{it.status.equals("LIVE",true)}
                if(items.isEmpty()) card("Hakuna mechi LIVE", "Tafadhali angalia tena baadaye.")
                items.forEach { card("${it.home_team}  ${it.home_score} - ${it.away_score}  ${it.away_team}", "${it.minute.orEmpty()}  •  ${it.league.orEmpty()}", true, it) }
            }
            "SCORES" -> {
                content.addView(label("MATOKEO NA RATIBA",20f,Color.rgb(16,24,32),true))
                if(cachedMatches.isEmpty()) card("Hakuna mechi zilizopatikana", "Unganisha API ili kuonyesha matokeo.")
                cachedMatches.forEach { card("${it.home_team}  ${it.home_score} - ${it.away_score}  ${it.away_team}", "${it.status} • ${it.scheduled_at.orEmpty()} • ${it.league.orEmpty()}",it.status.equals("LIVE",true),it) }
            }
            "NEWS" -> {
                content.addView(label("HABARI ZA MICHEZO",20f,Color.rgb(16,24,32),true))
                if(cachedNews.isEmpty()) card("Hakuna habari kwa sasa","Habari zitaonekana API ikipatikana.")
                cachedNews.forEach { card(it.headline,it.body) }
            }
            "TABLE" -> {
                content.addView(label("MSIMAMO WA LIGI",20f,Color.rgb(16,24,32),true))
                if(cachedStandings.isEmpty()) card("Hakuna msimamo uliowekwa","Msimamizi anaweza kuongeza msimamo kupitia API.")
                cachedStandings.sortedByDescending{it.points}.forEachIndexed { i,s -> card("${i+1}. ${s.team}", "${s.played} MP  •  ${s.won} W  •  ${s.drawn} D  •  ${s.lost} L  •  GD ${s.goals_for-s.goals_against}  •  ${s.points} PTS") }
            }
        }
    }

    private suspend fun refreshData() {
        var anySuccess = false
        runCatching { RetrofitClient.api.matches() }.onSuccess { cachedMatches=it; anySuccess=true }
        runCatching { RetrofitClient.api.news() }.onSuccess { cachedNews=it; anySuccess=true }
        runCatching { RetrofitClient.api.standings() }.onSuccess { cachedStandings=it; anySuccess=true }
        statusLine.text = if(anySuccess) "Imesasishwa • kila sekunde 15" else "API haijaunganishwa. Weka BASE_URL sahihi kwenye ApiConfig.kt."
        render()
    }

    override fun onDestroy() { refreshJob?.cancel(); super.onDestroy() }
}
