package com.jeffsport

data class Match(
    val id: Long,
    val home_team: String,
    val away_team: String,
    val home_score: Int = 0,
    val away_score: Int = 0,
    val minute: String? = "",
    val status: String = "Upcoming",
    val stream_url: String? = "",
    val league: String? = "",
    val home_logo_url: String? = "",
    val away_logo_url: String? = "",
    val scheduled_at: String? = "",
    val venue: String? = ""
)
data class News(val id: Long, val headline: String, val body: String, val created_at: String? = "")
data class Standing(
    val id: Long, val league: String, val team: String, val played: Int,
    val won: Int, val drawn: Int, val lost: Int, val goals_for: Int,
    val goals_against: Int, val points: Int
)
data class AppNotification(val id: Long, val title: String, val body: String, val created_at: String? = "")
