package com.jeffsport

object ApiConfig {
    // Badilisha hii baada ya ku-host backend yako. URL lazima iishie kwa /api/
    const val BASE_URL = "https://your-server.example/api/"
}
