package com.jeffsport

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class WatchLiveActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val view = PlayerView(this)
        setContentView(view)
        val url = intent.getStringExtra("streamUrl")
        if (url.isNullOrBlank() || !(url.startsWith("https://") || url.startsWith("http://"))) {
            Toast.makeText(this, "Hakuna stream URL halali iliyowekwa.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        player = ExoPlayer.Builder(this).build().also {
            view.player = it
            it.setMediaItem(MediaItem.fromUri(url))
            it.prepare()
            it.playWhenReady = true
        }
    }
    override fun onStop() { player?.release(); player=null; super.onStop() }
}
