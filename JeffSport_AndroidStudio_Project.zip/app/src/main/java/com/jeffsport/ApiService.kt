package com.jeffsport

import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("matches") suspend fun matches(@Query("status") status: String? = null): List<Match>
    @GET("news") suspend fun news(): List<News>
    @GET("standings") suspend fun standings(@Query("league") league: String = ""): List<Standing>
    @GET("notifications") suspend fun notifications(): List<AppNotification>
}
