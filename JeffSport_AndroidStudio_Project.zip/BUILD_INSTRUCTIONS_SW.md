# Jinsi ya kutengeneza JEFF SPORT APK

**Hii ni Android Studio project iliyopangwa kwa ajili ya build; si APK yenyewe.**

1. Pakua na fungua Android Studio kwenye kompyuta.
2. Extract `JeffSport_AndroidStudio_Project.zip`.
3. Android Studio: **Open** kisha chagua folder `JeffSport_AndroidStudio_Project`.
4. Ruhusu Gradle Sync na usakinishe Android SDK Platform 35 ikihitajika.
5. Fungua `app/src/main/java/com/jeffsport/ApiConfig.kt` na badilisha `BASE_URL` iwe HTTPS URL ya backend yako, mfano `https://api.domain-yako.tz/api/`.
6. Bonyeza **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. APK ya debug itapatikana kwa kawaida kwenye `app/build/outputs/apk/debug/app-debug.apk`.

Kama backend haijawekwa kwenye server yenye HTTPS, app haitapata scores/news. App inatumia stream URLs tu ambazo una haki ya kuzisambaza.
